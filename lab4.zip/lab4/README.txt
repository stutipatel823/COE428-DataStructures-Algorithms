My code works for printing the state machine, shows the character at the nextstate and it was able change states. However, it does not find the garbage collecttion.
