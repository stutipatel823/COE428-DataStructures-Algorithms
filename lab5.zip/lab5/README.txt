SUMMARY:
Part 1 worked!
Part 2 works only on geany or new applications. I perfomed all of my programming on my laptop using the geany application. The code worked when I ran it on my laptop. However, this code didn't work when I ran it on the VNC. I also emailed you regarding this.
Part 3 has no errors but doesn't work. I still haven't figured out why it doesn't work. 

Questions from Part 3:
1. I didn't use any collision resolution method because my hash function was designed in a way that a unique code would be formed for each word. example, hi = 317 but ih = 318. I wrote a sample code in a file called "try.c" to verify the method. 

2. I used a multiplication method(key = n*key+tag[i]), where key would be the ASCII code for each letter, tag[i] was the specific letter of the word and n=2 which was a random number used to give a start calculate a unique number for each unique word. To convert a string into a number, I used casting method. 
